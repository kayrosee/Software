
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Runner
 */
@WebServlet("/Software/Runner")
public class Runner extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		out.println("<!DOCTYPE html>");
		out.println("<html lang=\"en\">");
		out.println("<head>");
		out.println("	<meta charset=\"UTF-8\">");
		out.println("	<title>Runner</title>");
		out.println("	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">");
		out.println("</head>");
		out.println("<body>");
		out.println("<div class=\"container\">");
		out.println("	<h2>Customers Order:</h2>");
		out.println("	<table class=\"table table-bordered table-striped table-hover\">");
		out.println("		<tr>");
		out.println("			<th>Food</th>");
		out.println("			<th>Cost</th>");
		out.println("		</tr>");
		out.println("		<tr>");
		out.println("			<td>Tortilla Soup(Small)</td>");
		out.println("			<td>$2.99</td>");
		out.println("		</tr><tr>");
		out.println("			<td>Chips and Guac</td>");
		out.println("			<td>$2.99</td>");
		out.println("		</tr><tr>");
		out.println("			<td></td>");
		out.println("			<td></td>");
		out.println("		</tr><tr>");
		out.println("			<td><b>Total Cost</b></td>");
		out.println("			<td>$5.98</td>");
		out.println("</table>");
		
		out.println("	<h2>Customers Location:</h2>");
		out.println("	<h3>SH 260</h3>");
	
		out.println("	<br><input class=\"btn btn-primary\" type=\"submit\" name=\"submitBtn\" value=\"Confirmed\">");

		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		
		//Will Make Servlet for Deliverer
		System.out.println("testing");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);

	}

}
