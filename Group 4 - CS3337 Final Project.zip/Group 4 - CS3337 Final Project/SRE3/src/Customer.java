import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Customer
 */
@WebServlet("/Software/Customer")
public class Customer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		out.println("<!DOCTYPE html>");
		out.println("<html lang=\"en\">");
		out.println("<head>");
		out.println("	<meta charset=\"UTF-8\">");
		out.println("	<title>Checkout</title>");
		out.println("	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">");
		out.println("</head>");
		out.println("<body>");
		out.println("<div class=\"container\">");
		out.println("	<h2>Customers Order:</h2>");
		out.println("	<table class=\"table table-bordered table-striped table-hover\">");
		out.println("		<tr>");
		out.println("			<th>Food</th>");
		out.println("			<th>Cost</th>");
		out.println("		</tr>");
		out.println("		<tr>");
		out.println("			<td>Tortilla Soup(Small)</td>");
		out.println("			<td>$2.99</td>");
		out.println("		</tr><tr>");
		out.println("			<td>Chips and Guac</td>");
		out.println("			<td>$2.99</td>");
		out.println("		</tr><tr>");
		out.println("			<td></td>");
		out.println("			<td></td>");
		out.println("		</tr><tr>");
		out.println("			<td><b>Total Cost</b></td>");
		out.println("			<td>$5.98</td>");
		out.println("		</tr>");
		out.println("</table>");
		
		out.println("	<h2>Location:</h2>");
		out.println("		Location: <input type=\"text\" name=\"website\"> <br>");
		out.println("		Note to Deliverer: <br>");
		out.println("		<textarea name=\"descrip\"></textarea> <br>");
		out.println("	</form>");
		
		out.println("<br><form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\" target=\"_top\">\r\n" + 
				"<input type=\"hidden\" name=\"cmd\" value=\"_xclick\">\r\n" + 
				"<input type=\"hidden\" name=\"business\" value=\"davetwosando@yahoo.com\">\r\n" + 
				"<input type=\"hidden\" name=\"lc\" value=\"US\">\r\n" + 
				"<input type=\"hidden\" name=\"item_name\" value=\"Foods\">\r\n" + 
				"<input type=\"hidden\" name=\"amount\" value=\"5.98\">\r\n" + 
				"<input type=\"hidden\" name=\"currency_code\" value=\"USD\">\r\n" + 
				"<input type=\"hidden\" name=\"button_subtype\" value=\"services\">\r\n" + 
				"<input type=\"hidden\" name=\"no_note\" value=\"0\">\r\n" + 
				"<input type=\"hidden\" name=\"tax_rate\" value=\"0.000\">\r\n" + 
				"<input type=\"hidden\" name=\"shipping\" value=\"0.00\">\r\n" + 
				"<input type=\"hidden\" name=\"bn\" value=\"PP-BuyNowBF:btn_buynowCC_LG.gif:NonHostedGuest\">\r\n" + 
				"<input type=\"image\" src=\"https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif\" border=\"0\" name=\"submit\" alt=\"PayPal - The safer, easier way to pay online!\">\r\n" + 
				"<img alt=\"\" border=\"0\" src=\"https://www.paypalobjects.com/en_US/i/scr/pixel.gif\" width=\"1\" height=\"1\">\r\n" + 
				"</form>");
		out.println("		<br><input class=\"btn btn-primary\" type=\"submit\" name=\"submitBtn\" value=\"Send Order\">");
		
		out.println("	<form action=\"file:///C:/Users/davet/eclipse-workspace3337/SRE3/src/Robot.html\" method=\"post\">");
		out.println("	<input class=\"btn btn-primary\" type=\"submit\" name=\"submitBtn\" value=\"Send by Robot\">");
		out.println("	</form><br>");		
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
		
		//Will Make Servlet for Deliverer
		System.out.println("testing");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);

	}

}