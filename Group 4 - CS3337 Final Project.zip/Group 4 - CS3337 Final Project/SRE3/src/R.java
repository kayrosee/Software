

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class R
 */
@WebServlet("/R")
public class R extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		out.println("<!DOCTYPE html>");
		out.println("<html lang=\"en\">");
		out.println("<head>");
		out.println("	<meta charset=\"UTF-8\">");
		out.println("	<title>Robot</title>");
		out.println("	<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css\" integrity=\"sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO\" crossorigin=\"anonymous\">");
		out.println("</head>");
		out.println("<body>");
		out.println("<div class=\"container\">");
		
		out.println("<meta charset=\"utf-8\"><link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">\r\n" + 
				"<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n" + 
				"<style>\r\n" + 
				"* {\r\n" + 
				"  box-sizing: border-box;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"body {\r\n" + 
				"  font-family: Arial, Helvetica, sans-serif;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"/* Style the header */\r\n" + 
				"header {\r\n" + 
				"  background-color: #666;\r\n" + 
				"  padding: 20px;\r\n" + 
				"  text-align: center;\r\n" + 
				"  font-size: 20px;\r\n" + 
				"  color: white;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"/* Create two columns/boxes that floats next to each other */\r\n" + 
				"nav {\r\n" + 
				"  float: left;\r\n" + 
				"  width: 30%;\r\n" + 
				"  height: 600px; /* only for demonstration, should be removed */\r\n" + 
				"  background: rgb(167, 164, 164);\r\n" + 
				"  padding: 20px;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"/* Style the list inside the menu */\r\n" + 
				"nav ul {\r\n" + 
				"  list-style-type: none;\r\n" + 
				"  padding: 0;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"article {\r\n" + 
				"  float: left;\r\n" + 
				"  padding: 20px;\r\n" + 
				"  width: 70%;\r\n" + 
				"  background-color: #fff;\r\n" + 
				"  height: 600px; /* only for demonstration, should be removed */\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"/* Clear floats after the columns */\r\n" + 
				"section:after {\r\n" + 
				"  content: \"\";\r\n" + 
				"  display: table;\r\n" + 
				"  clear: both;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"/* Style the footer */\r\n" + 
				"footer {\r\n" + 
				"  background-color: #777;\r\n" + 
				"  padding: 10px;\r\n" + 
				"  text-align: center;\r\n" + 
				"  color: white;\r\n" + 
				"}\r\n" + 
				"\r\n" + 
				"/* Responsive layout - makes the two columns/boxes stack on top of each other instead of next to each other, on small screens */\r\n" + 
				"@media (max-width: 600px) {\r\n" + 
				"  nav, article {\r\n" + 
				"    width: 100%;\r\n" + 
				"    height: auto;\r\n" + 
				"  }\r\n" + 
				"}\r\n" + 
				"</style>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"\r\n" + 
				"<header>\r\n" + 
				"\r\n" + 
				"    <marquee behavior=\"scroll\" direction=\"right\">\r\n" + 
				"        <img style=\"width: 10% ; height: auto\" src=\"image/r2.jpg\" class=\"img-circle\">\r\n" + 
				"        <h1>Fast Delivery With Robot</h1>\r\n" + 
				"    </marquee>\r\n" + 
				"</header>\r\n" +
				"\r\n" + 
				"<section>\r\n" + 
				"  <nav>\r\n" + 
				"      <h2>Select your location</h2>\r\n" + 
				"      <p>Choose the location you would like to pick up your order:</p>\r\n" + 
				"      \r\n" + 
				"      <form>\r\n" + 
				"          <input type=\"radio\" name=\"location\" value=\"sh\" checked> Salazar Hall<br>\r\n" + 
				"          <input type=\"radio\" name=\"location\" value=\"kh\" checked> King Hall<br>\r\n" + 
				"          <input type=\"radio\" name=\"location\" value=\"U-US\" checked> University Student Union<br>\r\n" + 
				"          <input type=\"radio\" name=\"location\" value=\"ET\" checked> Engineering and Technology<br>\r\n" + 
				"      \r\n" + 
				"        <br>\r\n" + 
				"        <input type=\"button\" onclick=\"alert('Your food is on the way')\" value=\"Click Me!\">\r\n" + 
				"      </form>\r\n" + 
				"    <hr>\r\n" + 
				"    <ul>\r\n" + 
				"      <li><a href=\"https://www.uctronics.com/\">Robot Delivery </a></li>\r\n" + 
				"      \r\n" + 
				"      <hr>\r\n" + 
				"      <li><a href=\"SRE.html\">Back to the main</a></li>\r\n" + 
				"      <h3>Robot Component</h3>\r\n" + 
				"      <li>. 5MP Camera Module for Raspberry Pi</li>\r\n" + 
				"      <li>. L293D driver board for Raspberry Pi</li>\r\n" + 
				"      <li>. HC-SR04 Ultrasonic Sensor Module </li>\r\n" + 
				"      <li>. Line Tracking Module </li>\r\n" + 
				"      <li>. HC-05 Bluetooth Module</li>\r\n" + 
				"      <li>. 9g micro servo motor</li>\r\n" + 
				"      <li>. Geared Motors (1:48) </li>\r\n" + 
				"    </ul>\r\n" + 
				"  </nav>\r\n" + 
				"  \r\n" + 
				"  <article>\r\n" + 
				"    <p id=\"demo\"></p>\r\n" + 
				"    <img style=\"width: 90% ; height: auto\" src=\"image/4.png\" class=\"img-auto\">\r\n" + 
				"    <script>\r\n" + 
				"        function myFunction() \r\n" + 
				"        {\r\n" + 
				"            document.getElementById(\"demo\").innerHTML =\"The robot is on the Way it will take 10 minutes to deliver\";\r\n" + 
				"            document.getElementById(\"demo\").style.fontSize = \"20px\";\r\n" + 
				"            document.getElementById(\"demo\").style.color = \"blue\";\r\n" + 
				"            document.getElementById(\"demo\").style.backgroundColor = \"red\";\r\n" + 
				"        }\r\n" + 
				"\r\n" + 
				"        </script>\r\n" + 
				"        <button typy = \"button\" onclick = \"myFunction()\"> Click when you ready to deliver </button>\r\n" + 
				"  </article>\r\n" + 
				"</section>\r\n" + 
				"\r\n" + 
				"<footer>\r\n" + 
				"    <marquee behavior=\"scroll\" direction=\"left\">\r\n" + 
				"        <img style=\"width: 10% ; height: auto\" src=\"image/r1.jpg\" class=\"img-circle\">\r\n" + 
				"        \r\n" + 
				"    </marquee>\r\n" + 
				"    <br>\r\n" + 
				"    <img style=\"width: 70% ; height: auto\" src=\"image/uc1.jpg\" class=\"img-auto\">\r\n" + 
				"    <hr>\r\n" + 
				"    <img style=\"width: 70% ; height: auto\" src=\"image/uc2.jpg\" class=\"img-auto\">\r\n" + 
				"    <hr>\r\n" + 
				"    <img style=\"width: 70% ; height: auto\" src=\"image/uc3.jpg\" class=\"img-auto\">\r\n" + 
				"    <hr>\r\n" + 
				"    <img style=\"width: 70% ; height: auto\" src=\"image/uc4.jpg\" class=\"img-auto\">\r\n" + 
				"    <hr>\r\n" + 
				"</footer>\r\n" + 
				"\r\n" + 
				"</body>\r\n" + 
				"</html>\r\n" + 
				"");


		out.println("</div>");
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
